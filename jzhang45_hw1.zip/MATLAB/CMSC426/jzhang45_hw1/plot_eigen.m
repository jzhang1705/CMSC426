data1 = load('/Users/jeffreyzhang/Documents/MATLAB/CMSC426/jzhang45_hw1/data/data1.mat');
data2 = load('/Users/jeffreyzhang/Documents/MATLAB/CMSC426/jzhang45_hw1/data/data2.mat');
data3 = load('/Users/jeffreyzhang/Documents/MATLAB/CMSC426/jzhang45_hw1/data/data3.mat');

syms l;
syms x;
syms y;

% data1 
x1 = data1.pts(1,:).';
y1 = data1.pts(2,:).';
% construct data1 covariance matrix
mx1  = mean(x1);
sx1_2 = 1/199 * sum((x1 - mx1).^2);
my1  = mean(y1);
sy1_2 = 1/199 * sum((y1 - my1).^2);
sx1y1 = 1/199 * sum((y1 - my1).*(x1 - mx1));
cov_matrix1 = [sx1_2 sx1y1; sx1y1 sy1_2];
% find eigenvectors and eigenvalues
AAT = cov_matrix1*199;
[U,S,V] = svd(AAT);
figure(1)
scatter(x1,y1, 'b')
hold on
X1 = [U(1,1), -U(1,1)]*sqrt(sqrt(S(1,1)))*2;
X2 = [U(2,1), -U(2,1)]*sqrt(sqrt(S(1,1)))*2;
Y1 = [U(1,2), -U(1,2)]*sqrt(sqrt(S(2,2)))*2;
Y2 = [U(2,2), -U(2,2)]*sqrt(sqrt(S(2,2)))*2;
axis([-200,200,-200,200])
plot(X1,X2,'LineWidth',3)
plot(Y1,Y2,'LineWidth',3)
hold off

% data2
x2 = data2.pts(1,:).';
y2 = data2.pts(2,:).';
mx2  = mean(x2);
sx2_2 = 1/199 * sum((x2 - mx2).^2);
my2  = mean(y2);
sy2_2 = 1/199 * sum((y2 - my2).^2);
sx2y2 = 1/199 * sum((y2 - my2).*(x2 - mx2));
cov_matrix2 = [sx2_2 sx2y2; sx2y2 sy2_2];
% find eigenvectors and eigenvalues
AAT = cov_matrix2*199;
[U,S,V] = svd(AAT);
figure(2);
scatter(x2,y2, 'b')
hold on
X1 = [U(1,1), -U(1,1)]*sqrt(sqrt(S(1,1)))*2;
X2 = [U(2,1), -U(2,1)]*sqrt(sqrt(S(1,1)))*2;
Y1 = [U(1,2), -U(1,2)]*sqrt(sqrt(S(2,2)))*2;
Y2 = [U(2,2), -U(2,2)]*sqrt(sqrt(S(2,2)))*2;
axis([-200,200,-200,200])
plot(X1,X2,'LineWidth',3)
plot(Y1,Y2,'LineWidth',3)
hold off

% data3
x3 = data3.pts(1,:).';
y3 = data3.pts(2,:).';
mx3  = mean(x3);
sx3_2 = 1/199 * sum((x3 - mx3).^2);
my3  = mean(y3);
sy3_2 = 1/199 * sum((y3 - my3).^2);
sx3y3 = 1/199 * sum((y3 - my3).*(x3 - mx3));
cov_matrix3 = [sx3_2 sx3y3; sx3y3 sy3_2];
% find eigenvectors and eigenvalues
AAT = cov_matrix3*199;
[U,S,V] = svd(AAT);
figure(3)
scatter(x3,y3, 'b')
hold on
X1 = [U(1,1), -U(1,1)]*sqrt(sqrt(S(1,1)))*2;
X2 = [U(2,1), -U(2,1)]*sqrt(sqrt(S(1,1)))*2;
Y1 = [U(1,2), -U(1,2)]*sqrt(sqrt(S(2,2)))*2;
Y2 = [U(2,2), -U(2,2)]*sqrt(sqrt(S(2,2)))*2;
axis([-200,200,-200,200])
plot(X1,X2,'LineWidth',3)
plot(Y1,Y2,'LineWidth',3)
hold off