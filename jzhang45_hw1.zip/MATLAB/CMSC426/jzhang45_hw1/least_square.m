data1 = load('/Users/jeffreyzhang/Documents/MATLAB/CMSC426/jzhang45_hw1/data/data1.mat');
data2 = load('/Users/jeffreyzhang/Documents/MATLAB/CMSC426/jzhang45_hw1/data/data2.mat');
data3 = load('/Users/jeffreyzhang/Documents/MATLAB/CMSC426/jzhang45_hw1/data/data3.mat');

format long

% data1
X1 = data1.pts(1,:).';
Y1 = data1.pts(2,:).';
B = X1\Y1;
y_cal1 = B*X1;

l = -100000;
X1 = [ones(size(X1,1),1) X1];
B = (X1.'*X1 + l*eye(2))\(X1.'*Y1);
y_cal_adj1 = X1*B;					

x1 = data1.pts(1,:).';
y1 = data1.pts(2,:).';
mx1  = mean(x1);
my1 =  mean(y1);
sx1y1 = 1/199 * sum((y1 - my1).*(x1 - mx1));
[m,b] = my_ransac(x1,y1,sqrt(sx1y1));
y_1 = m*x1 + b;

figure(1);
scatter(x1,y1,'DisplayName','data3');
hold on;
plot(x1, y_cal1,'DisplayName','Ordinary');
plot(X1(:,2), y_cal_adj1,'DisplayName','Ridge');
plot(x1,y_1,'DisplayName','RANSAC');
axis([-200,200,-200,200]);
legend;
hold off;

% data2
X2 = data2.pts(1,:).';
Y2 = data2.pts(2,:).';
B = X2\Y2;
y_cal2 = B*X2;

l = -300000;
X2 = [ones(size(X2,1),1) X2];
B = (X2.'*X2 + l*eye(2))\(X2.'*Y2); 
y_cal_adjust2 = X2*B;


x2 = data2.pts(1,:).';
y2 = data2.pts(2,:).';
mx2  = mean(x2);
my2 =  mean(y2);
sx2y2 = 1/199 * sum((y2 - my2).*(x2 - mx2));
[m,b] = my_ransac(x2,y2,sqrt(sx2y2));
y_2 = m*x2 + b;

figure(2);
scatter(x2,y2,'DisplayName','data3');
hold on;
plot(x2, y_cal2,'DisplayName','Ordinary');
plot(X2(:,2), y_cal_adjust2,'DisplayName','Ridge');
plot(x2,y_2,'DisplayName','RANSAC');
axis([-200,200,-200,200]);
legend;
hold off;

% data3
X3 = data3.pts(1,:).';
Y3 = data3.pts(2,:).';
B = X3\Y3;
y_cal3 = B*X3;

lambda = -500000;
X3 = [ones(size(X3,1),1) X3];
B = (X3.'*X3 + lambda*eye(2))\(X3.'*Y3); 
y_cal_adjust3 = X3*B;	


x3 = data3.pts(1,:).';
y3 = data3.pts(2,:).';
mx3  = mean(x3);
my3 =  mean(y3);
sx3y3 = 1/199 * sum((y3 - my3).*(x3 - mx3));
[m,b] = my_ransac(x3,y3,sqrt(sx3y3));
y_3 = m*x3 + b;

figure(3);
scatter(x3,y3,'DisplayName','data3');
hold on;
plot(x3, y_cal3,'DisplayName','Ordinary');
plot(X3(:,2), y_cal_adjust3,'DisplayName','Ridge');
plot(x3,y_3,'DisplayName','RANSAC');
axis([-200,200,-200,200]);
legend;
hold off;

%v1 = x, v2 = y, std = standard deviation or any inlier threshold
function [m,b] = my_ransac(v1,v2,std)
    m = 0;
    b = 0;
    best_fit = 0;
    for i = 1:199
        for j = i+1:200
            temp_fit = 0;
            x1 = v1(i);
            y1 = v2(i);
            x2 = v1(j);
            y2 = v2(j);
            temp_m = (y2 - y1)/(x2 - x1);
            temp_b = y1 - temp_m*x1;
            denominator = sqrt(temp_m^2 + 1);
            for k = 1:200
                if(abs(temp_m*v1(k) - v2(k) + temp_b)/denominator <= std)
                     temp_fit = temp_fit + 1;
                end
            end
            temp_fit = temp_fit - 1;
            if(temp_fit >= best_fit)
                best_fit = temp_fit;
                m = temp_m;
                b = temp_b;
            end
        end
    end
end
